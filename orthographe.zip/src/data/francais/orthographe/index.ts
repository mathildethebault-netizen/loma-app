    // Index pour le domaine: Orthographe (Cycle 2)
    import type { ExerciseModule } from "./common/types";
    const base: ExerciseModule = [];
    export const exercises = [...base] as const;
    export default exercises;
    