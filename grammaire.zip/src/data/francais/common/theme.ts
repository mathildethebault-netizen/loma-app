export const pastelTheme = {
  brand: { primary: "#8BC6EC", secondary: "#F6D5F7", accent: "#B8E1DD" },
  surfaces: { base: "#FDFDFE", soft: "#F6F8FB", strong: "#E9EEF6" },
  text: { base: "#1D2A39", soft: "#516173" },
  states: { correct: "#B9E6A5", wrong: "#F9C6C9", info: "#FFE6A7" },
} as const;

export const font = {
  family: "Nunito, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif",
};
