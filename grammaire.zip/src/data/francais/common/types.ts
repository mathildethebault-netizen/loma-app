export type Domaine =
  | "grammaire"
  | "conjugaison"
  | "orthographe"
  | "lexique-expression";

export type TypeExo =
  | "qcm"
  | "vrai-faux"
  | "texte-a-trous"
  | "classement"
  | "reordonner"
  | "association"
  | "reponse-courte";

export interface ItemExo {
  question: string;
  options?: string[];
  reponse: string | string[];
  explication?: string;
}

export interface MetaExo {
  difficulte?: 1 | 2 | 3;
  tempsEstime?: number;
  competencies?: string[];
  niveau?: "cycle2" | "cycle3" | "cycle4" | "lycee";
  source?: string;
  reference?: string;
  objectif?: string;
  objectifCode?: string;
}

export interface StyleExo {
  theme: "pastel";
  font: "Nunito";
}

export interface Exercise {
  id: string;
  domaine: Domaine;
  sousDomaine?: string;
  type: TypeExo;
  consigne: string;
  items: ItemExo[];
  tags?: string[];
  meta?: MetaExo;
  style?: StyleExo;
}

export type ExerciseModule = Exercise[];
