// src/components/SelectObjectif.tsx
import objectifsCycle2 from "src/data/francais/common/objectifsCycle2.json";

type Props = {
  domaine: "grammaire" | "conjugaison" | "orthographe" | "lexique-expression";
  value?: string;
  onChange: (val: string) => void;
};

export default function SelectObjectif({ domaine, value = "", onChange }: Props) {
  const liste = (objectifsCycle2 as any)[domaine] || [];
  return (
    <select
      className="border rounded-xl p-2 bg-pastel-soft font-nunito"
      value={value}
      onChange={(e) => onChange(e.target.value)}
    >
      <option value="">Sélectionner un objectif Éduscol</option>
      {liste.map((obj: any) => (
        <option key={obj.code} value={obj.intitule}>
          {obj.code} – {obj.intitule}
        </option>
      ))}
    </select>
  );
}
